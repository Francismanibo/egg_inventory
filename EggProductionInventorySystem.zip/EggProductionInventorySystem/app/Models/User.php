<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
class User extends Authenticatable { use Notifiable;
 protected $fillable=['name','email','password','role','status']; protected $hidden=['password','remember_token'];
 protected function casts():array{return ['email_verified_at'=>'datetime','password'=>'hashed'];}
 public function productionRecords(){return $this->hasMany(ProductionRecord::class,'recorded_by');}
 public function inventoryTransactions(){return $this->hasMany(InventoryTransaction::class,'recorded_by');}
}
