<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up():void{Schema::create('users',function(Blueprint $t){$t->id();$t->string('name',100);$t->string('email',150)->unique();$t->timestamp('email_verified_at')->nullable();$t->string('password');$t->string('role',50)->default('inventory');$t->string('status',20)->default('active');$t->rememberToken();$t->timestamps();});} public function down():void{Schema::dropIfExists('users');} };
